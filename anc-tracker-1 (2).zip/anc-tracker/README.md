# ANC Tracker PWA – PHC MP Banjara
## Setup & Deployment Guide

---

## 📁 Files in this package
| File | Purpose |
|------|---------|
| `index.html` | Main app (all-in-one PWA) |
| `manifest.json` | PWA install metadata |
| `sw.js` | Service worker (offline + push) |
| `icon-192.png` | App icon (add your own) |
| `icon-512.png` | App icon large (add your own) |

---

## 🔥 STEP 1 – Firebase Setup

1. Go to https://console.firebase.google.com
2. Create a new project (e.g. `phc-anc-tracker`)
3. Enable **Realtime Database** → Start in test mode
4. Click ⚙️ Project Settings → Your apps → Add Web App
5. Copy your Firebase config object

**In `index.html`, find this section and replace:**
```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT-default-rtdb.firebaseio.com",
  projectId: "YOUR_PROJECT",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

---

## 🚀 STEP 2 – Host on GitHub Pages

1. Create a GitHub repo (e.g. `anc-tracker`)
2. Upload all 4 files (index.html, manifest.json, sw.js, icons)
3. Go to Repo Settings → Pages → Deploy from main branch
4. Your URL: `https://YOUR-USERNAME.github.io/anc-tracker/`

> You can add it to the existing `januaithabathula-art.github.io/PHC-MPBANJARA/` repo in a subfolder too.

---

## 📱 STEP 3 – Install on Android

1. Open the URL in **Chrome** on Android
2. Tap ⋮ menu → **"Add to Home Screen"**
3. App installs like a native Android app
4. Works offline after first load

---

## 🔔 Notifications

The app fires push notifications **on every app open** for:
- 🚨 EDD within 15 days
- ⚠️ ANC visit overdue
- 📅 ANC visit due now

ANM must tap "Enable Notifications" on first launch.

For **background notifications** (when app is closed), you need a push server 
(Firebase Cloud Messaging). This can be added later if needed.

---

## 📋 GoI ANC Schedule Used

| Visit | Weeks | When |
|-------|-------|------|
| 1st ANC | < 12 weeks | 1st Trimester |
| 2nd ANC | 14–26 weeks | 2nd Trimester |
| 3rd ANC | 28–34 weeks | 3rd Trimester |
| 4th ANC | 36+ weeks | Pre-delivery |

---

## 🗂️ Firebase Data Structure

```
anc_patients/
  {patientId}/
    name, husband, village, subcentre
    lmp, edd
    age, gravida, jssy, mobile, blood
    highrisk, remarks
    status: "active" | "delivered"
    registeredOn
    checkups/
      anc1/ { date, bp, weight, hb, albumin, sugar, fhr, fm, remarks }
      anc2/ { ... }
      anc3/ { ... }
      anc4/ { ... }
    deliveryDate, deliveryType, deliveryPlace
    babyWeight, babyGender, babyOutcome, deliveryRemarks
```

---

## 🆘 Support
Prabhakar – Pharmacy Officer, PHC MP Banjara
Bhadradri Kothagudem District, Telangana
