// ANC Tracker Service Worker – PHC MP Banjara
const CACHE_NAME = 'anc-tracker-v1';
const ASSETS = [
  './',
  './index.html',
  './manifest.json'
];

// Install – cache shell
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

// Activate – clean old caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Fetch – network first, fall back to cache
self.addEventListener('fetch', event => {
  // Skip Firebase and external requests
  if (!event.request.url.startsWith(self.location.origin)) return;
  event.respondWith(
    fetch(event.request).catch(() => caches.match(event.request))
  );
});

// Push notification handler
self.addEventListener('push', event => {
  let data = { title: 'ANC Tracker', body: 'You have an ANC alert.' };
  if (event.data) {
    try { data = event.data.json(); } catch { data.body = event.data.text(); }
  }
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: 'icon-192.png',
      badge: 'icon-192.png',
      vibrate: [200, 100, 200],
      data: data.url || '/',
      actions: [
        { action: 'open', title: 'Open App' },
        { action: 'close', title: 'Dismiss' }
      ]
    })
  );
});

// Notification click
self.addEventListener('notificationclick', event => {
  event.notification.close();
  if (event.action !== 'close') {
    event.waitUntil(clients.openWindow('./index.html'));
  }
});

// Background sync – check alerts daily
self.addEventListener('periodicsync', event => {
  if (event.tag === 'anc-daily-check') {
    event.waitUntil(checkAndNotify());
  }
});

async function checkAndNotify() {
  // This is called by the browser periodically (if registered)
  // The main app handles live notification on open
  self.registration.showNotification('ANC Tracker – Daily Check', {
    body: 'Open the app to see today\'s ANC alerts.',
    icon: 'icon-192.png',
    badge: 'icon-192.png'
  });
}
